[comment]: (Header-of-readme)
# RefreshDB deployment scripts
[comment]: (Story-related-to-change)
**Last story:**
#####  APPPLM-3746 As a Campinas ERP user I want the PLM data to be interfaced to our moved ERP system

[comment]: (Version)
**version:** 6.2.4

[comment]: (Created-for)
**Created for:** Refreshing of PLM environments

[comment]: (ReleaseNotes)
**Release notes:** 
	* Change of PRC server

See also [PLM e6.2.1. Refreshing a PLM Environment with Production data](https://marel-tp.atlassian.net/wiki/spaces/TEAM/pages/23796262/PLM+e6.2.1.+Refreshing+a+PLM+Environment+with+Production+data) for more information.

